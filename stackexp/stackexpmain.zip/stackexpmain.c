#include <stdio.h>
#include <stdlib.h>
#include<string.h>

#define MAX 100

typedef char element;

typedef struct {
	element stack[MAX];
	int top;
}Stacktype;
void init_stack(Stacktype* s)
{
	s->top = -1;
}
int is_empty(Stacktype* s)
{
	return(s->top == -1);
}

int is_full(Stacktype* s)
{
	return (s->top == (MAX - 1));
}

void push(Stacktype* s, element item)
{
	if (is_full(s))
	{
		fprintf(stderr, "���� ���� ��\n");
		return;
	}
	else s->stack[++(s->top)] = item;
}

element pop(Stacktype *s)
{
	if (is_empty(s))
	{
		fprintf(stderr, "���� ��\n");
		return 0;

	}
	else {
		return s->stack[(s->top)--];
	}
}
element peek(Stacktype* s)
{
	if (is_empty(s))
	{
		fprintf(stderr, "���� ��\n");
		return 0;

	}
	else {
		return s->stack[(s->top)--];
	}
}

int eval(char exp[])
{
	int i = 0,op1,op2;
	char ch;
	int len = strlen(exp);
	Stacktype s;

	init_stack(&s);
	for (i = 0; i < len; i++) {
		ch = exp[i];
		if(ch!='+'&& ch!='-'&&ch!='*'&&ch!='/'){
			push(&s, ch);
		}

		else {
			op2 = pop(&s);
			op1 = pop(&s);
			switch (ch) {
			case'+':push(&s, (op1-'0') + (op2-'0')); break;
			case'-':push(&s, (op1 - '0') - (op2 - '0')); break;
			case'*':push(&s, (op1 - '0') * (op2 - '0')); break;
			case'/':push(&s, (op1 - '0') / (op2 - '0')); break;

			}
		}
	}
	return pop(&s);
}


int main(void)
{
	char exp[MAX];
	int result;


	printf("������ �Է��ϼ���: ");
	scanf_s("%s",exp);

	if (exp >= '0' && exp <= '9' && exp == '+' && exp == '-' && exp == '*' && exp == '/')
	{
		result = eval(exp);
		printf("����� %d�Դϴ�.\n", result);
	}
	else {
		printf("�����Դϴ�");
	}

	return 0;
}